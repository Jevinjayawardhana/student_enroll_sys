﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace jevin
{
    public partial class Employee_details : Form
    {


        public Employee_details()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            string employeeno = txt_ID.Text;
            string fn = txt_first.Text;
            string ln = txt_last.Text;
            string dob = dateTimePicker1.Value.ToString();
            //dateTimePicker1.Format = DateTimePickerFormat.Custom;


            // dateTimePicker1.CustomFormat = "yyyy/mm/dd";
            // string male = btn_male.Text;
            // string female = btn_female.Text;
            string gender;
            if (btn_male.Checked)
            {
                gender = "male";
            }
            else
            {
                gender = "female";
            }
            string address = txt_address.Text;
            string email = txt_email.Text;
            string pno = txt_mobie.Text;
            string hno = txt_home.Text;
            string pn = txt_parentsname.Text;
            string nic = txt_nic.Text;
            string cn = txt_contactnumber.Text;

            SqlConnection con = new SqlConnection("Data Source=LAPTOP-6V289DHS\\SQLEXPRESS;Initial Catalog=studentDB;Integrated Security=True");

            SqlCommand cmd = null;
            //empno	fname	lname	dob	gender	eaddress	email	phoneno	homeno	deptname	designation	qualification
            cmd = new SqlCommand("insert into studenttb (fName,lname,dob,gender,eaddress,email,phoneno,homeno,parentname,NIC,Contactnumber) values('" + fn + "','" + ln + "','" + dob + "', '" + gender + "','" + address + "','" + email + "','" + pno + "','" + hno + "','" + pn + "','" + nic + "','" + cn + "')", con);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Successfully Added");


            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex);
                con.Close();


            }
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            string id = txt_ID.Text;
            SqlConnection con = new SqlConnection("Data Source=LAPTOP-6V289DHS\\SQLEXPRESS;Initial Catalog=studentDB;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("select * from studenttb where stdno = '" + id + "'", con);

            try
            {
                con.Open();
                SqlDataReader myR = cmd.ExecuteReader(); //get the search result to myR    variable

                if (myR.HasRows)
                {
                    while (myR.Read())


                    {
                        txt_first.Text = myR["fName"].ToString();
                        txt_last.Text = myR["lname"].ToString();

                        dateTimePicker1.Text = myR["dob"].ToString();//recheck

                        string gender;
                        if (btn_male.Checked)
                        {
                            gender = "male";
                        }
                        else
                        {
                            gender = "female";
                        }

                        btn_female.Text = myR["gender"].ToString();
                        txt_address.Text = myR["eaddress"].ToString();
                        txt_email.Text = myR["email"].ToString();
                        txt_mobie.Text = myR["phoneno"].ToString();
                        txt_home.Text = myR["homeNo"].ToString();
                        txt_parentsname.Text = myR["parentname"].ToString();
                        txt_nic.Text = myR["NIC"].ToString();
                        txt_contactnumber.Text = myR["Contactnumber"].ToString();


                    }
                }
                else
                {
                    MessageBox.Show("Sorry, No record from this id..");
                }

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex);
                con.Close();


            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            //empno	fname	lname	dob	gender	eaddress	email	phoneno	homeno	deptname	designation	qualification

            string id = txt_ID.Text;
            string fn = txt_first.Text;
            string ln = txt_last.Text;
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "yyyy/MM/dd";

            string gender;
            if (btn_male.Checked)
            {
                gender = "male";
            }
            else
            {
                gender = "female";
            }
            string address = txt_address.Text;
            string email = txt_email.Text;
            string pno = txt_mobie.Text;
            string hno = txt_home.Text;
            string pn = txt_parentsname.Text;
            string nic = txt_nic.Text;
            string cn = txt_contactnumber.Text;

            SqlConnection con = new SqlConnection("Data Source=LAPTOP-6V289DHS\\SQLEXPRESS;Initial Catalog=studentDB;Integrated Security=True");
            SqlCommand cmd = null;
            //cmd = new SqlCommand("insert into studenttb (fName,lname,dob,gender,eaddress,email,phoneno,homeno,parentname,NIC,Contactnumber) values('" + fn + "','" + ln + "','" + dob + "', '" + gender + "','" + address + "','" + email + "','" + pno + "','" + hno + "','" + pn + "','" + nic + "','" + cn + "')", con);
            cmd = new SqlCommand("Update studenttb SET fName='" + fn + "',lname='" + ln + "',dob='" + dateTimePicker1.Text + "',gender='" + gender + "',eaddress='" + address + "',email='" + email + "',phoneno='" + pno + "',homeNo='" + hno + "',parentname='" + pn + "',NIC='" + nic + "',Contactnumber= '" + cn + "' Where stdno = '" + id + "'", con);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Successfully Updated");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex);
                con.Close();
            }

        }

        private void Employee_details_Load(object sender, EventArgs e)
        {

        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            string id = txt_ID.Text;
            string fn = txt_first.Text;
            string ln = txt_last.Text;
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "yyyy/MM/dd";

            string gender;
            if (btn_male.Checked)
            {
                gender = "male";
            }
            else
            {
                gender = "female";
            }


            string address = txt_address.Text;
            string email = txt_email.Text;
            string pno = txt_mobie.Text;
            string hno = txt_home.Text;
            string pn = txt_parentsname.Text;
            string nic = txt_nic.Text;
            string cn = txt_contactnumber.Text;

            SqlConnection con = new SqlConnection("Data Source=LAPTOP-6V289DHS\\SQLEXPRESS;Initial Catalog=studentDB;Integrated Security=True");

            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Delete from Studenttb where Stdno = '" + id + "'",con);


                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Successfully Deleted");

                txt_ID.Clear();
                txt_first.Clear();
                txt_last.Clear();

                dateTimePicker1.CustomFormat = "yyyy/mm/dd";
                DateTime thisDay = DateTime.Today;
                dateTimePicker1.Text = thisDay.ToString();

                btn_male.Checked = false;
                btn_female.Checked = false;

                txt_address.Clear();
                txt_email.Clear();
                txt_mobie.Clear();
                txt_home.Clear();
                txt_parentsname.Clear();
                txt_nic.Clear();
                txt_contactnumber.Clear();
            }
            catch (Exception ex)
            {
                //throw;
                MessageBox.Show(ex.Message);
                con.Close();

            }


        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt_ID.Clear();
            txt_first.Clear();
            txt_last.Clear();

            dateTimePicker1.CustomFormat = "yyyy/mm/dd";
            DateTime thisDay = DateTime.Today;
            dateTimePicker1.Text = thisDay.ToString();

            btn_male.Checked = false;
            btn_female.Checked = false;

            txt_address.Clear();
            txt_email.Clear();
            txt_mobie.Clear();
            txt_home.Clear();
            txt_parentsname.Clear();
            txt_nic.Clear();
            txt_contactnumber.Clear();
        }

        private void btn_logout_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
            Form1 f1 = new Form1();
            f1.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void txt_parentsname_TextChanged(object sender, EventArgs e)
        {

        }
    }
}