﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace jevin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txt_username.Text == "")
            {
      MessageBox.Show("Enter the Username", "Worning", MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
            }
            else if (txt_password.Text == "")
            {
                MessageBox.Show("Enter the Password", "Worning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);


            }


            else
            {
                try
                {
                    SqlConnection con = new SqlConnection("Data Source=LAPTOP-6V289DHS\\SQLEXPRESS;Initial Catalog=studentDB;Integrated Security=True");
                    //SqlCommand cmd = null;

                    SqlCommand cmd = new SqlCommand("select * from Logintb where username=@userName and upassword=@upassword", con);

                    cmd.Parameters.AddWithValue("@username", txt_username.Text);
                    cmd.Parameters.AddWithValue("@upassword", txt_password.Text);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable(); 


                    da.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        MessageBox.Show("Login Successful..!", "Successful");

                        this.Hide();
                        Employee_details jw = new Employee_details();
                        jw.Show();

                    }
                    else
                    {
                        MessageBox.Show("Invalid Login Credentials, Please check Username and Password then Try Again.",
                        "Invalid login Details",
                          MessageBoxButtons.OK,
                               MessageBoxIcon.Error);

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("" + ex);

                }
            }
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {

        }
    }
}

