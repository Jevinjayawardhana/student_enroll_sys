

create database studentDB

use studentDB;


create table studenttb(stdno int identity(00133124,1)primary key,fname varchar(255),lname varchar(255),dob date, gender varchar(255),eaddress varchar (255),
email varchar(255),phoneno int,homeno int, parentname varchar(255), NIC varchar(255),Contactnumber varchar(255));

create table logintb (uid int identity (1000,1)primary key,username varchar(255),upassword varchar (255));
insert into logintb values('jevin1','jevin@123');
insert into logintb values('1','2');
select*from  logintb
select*from studenttb;
drop table studenttb
 select * from studenttb where stdno = '101';

